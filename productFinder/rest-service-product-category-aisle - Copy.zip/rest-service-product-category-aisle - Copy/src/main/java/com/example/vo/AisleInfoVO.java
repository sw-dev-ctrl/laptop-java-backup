package com.example.vo;

public class AisleInfoVO {
	private String productName;
	private String categoryName;
	private String categoryDescription;
	private String productDescription;
	private String aisleName;
	private String aisleDescription;
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public String getAisleName() {
		return aisleName;
	}
	public void setAisleName(String aisleName) {
		this.aisleName = aisleName;
	}
	public String getAisleDescription() {
		return aisleDescription;
	}
	public void setAisleDescription(String aisleDescription) {
		this.aisleDescription = aisleDescription;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public String getCategoryDescription() {
		return categoryDescription;
	}
	public void setCategoryDescription(String categoryDescription) {
		this.categoryDescription = categoryDescription;
	}
	
	
}
